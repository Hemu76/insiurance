package com.ilp.ims.Bean;

public class HealthInsurance extends Insurance {

}
